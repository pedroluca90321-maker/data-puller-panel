import ipaddress
import socket
from urllib.parse import urljoin, urlparse

import pandas as pd
import requests
import streamlit as st
from bs4 import BeautifulSoup

st.set_page_config(
    page_title="Data Puller Panel",
    page_icon="📊",
    layout="wide",
)

st.markdown(
    """
    <style>
      .stApp { background: #0e1117; }
      [data-testid="stSidebar"] { background: #151a23; }
      .block-container { padding-top: 2rem; }
      .stButton > button {
        width: 100%; background: #0068c9; color: white;
        border: 0; border-radius: 10px; min-height: 2.8rem;
      }
      .stTextInput input { border-radius: 10px; }
      div[data-testid="stMetric"] {
        background: #151a23; padding: 1rem; border-radius: 12px;
        border: 1px solid #293241;
      }
    </style>
    """,
    unsafe_allow_html=True,
)

st.title("📊 Painel de Extração de Dados")
st.write("Insira o endereço de uma página pública para coletar os links e títulos encontrados no HTML.")

with st.sidebar:
    st.header("⚙️ Configurações")
    user_agent = st.text_input(
        "User-Agent (opcional)",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124.0 Safari/537.36",
    )
    max_results = st.slider("Limite de resultados", 10, 100, 50)
    st.info("Use apenas em sites que você tem autorização para consultar. Alguns sites bloqueiam automações.")

left, right = st.columns([3, 1])
with left:
    url_input = st.text_input("🔗 Link do site", placeholder="https://exemplo.com")
with right:
    st.write("")
    st.write("")
    btn_puxar = st.button("Puxar dados 🚀", type="primary")

def validate_public_url(raw_url: str) -> str:
    """Validate URL format and avoid requests to localhost/private IP addresses."""
    parsed = urlparse(raw_url.strip())
    if parsed.scheme not in ("http", "https") or not parsed.hostname:
        raise ValueError("Digite um endereço completo começando com http:// ou https://.")
    hostname = parsed.hostname.lower()
    if hostname == "localhost" or hostname.endswith(".local"):
        raise ValueError("Endereços locais não são permitidos.")
    try:
        addresses = socket.getaddrinfo(hostname, None)
        for address in addresses:
            ip = ipaddress.ip_address(address[4][0])
            if not ip.is_global:
                raise ValueError("O endereço precisa apontar para um servidor público.")
    except socket.gaierror:
        raise ValueError("Não foi possível localizar o domínio informado.")
    return raw_url.strip()

if btn_puxar:
    if not url_input.strip():
        st.error("Por favor, insira o link de um site.")
    else:
        try:
            target_url = validate_public_url(url_input)
            with st.spinner("Acessando o site e extraindo os links..."):
                headers = {"User-Agent": user_agent.strip() or "DataPuller/1.0"}
                response = requests.get(
                    target_url,
                    headers=headers,
                    timeout=15,
                    allow_redirects=True,
                )
                response.raise_for_status()
                soup = BeautifulSoup(response.text, "html.parser")
                found_links = soup.find_all("a", href=True)

                rows = []
                for link in found_links[:max_results]:
                    href = link.get("href", "").strip()
                    if not href:
                        continue
                    rows.append({
                        "Título": link.get_text(" ", strip=True) or "Sem título",
                        "URL": urljoin(response.url, href),
                    })

                df = pd.DataFrame(rows, columns=["Título", "URL"])

            if not df.empty:
                st.success(f"Concluído! {len(df)} links encontrados.")
                m1, m2 = st.columns(2)
                m1.metric("Links extraídos", len(df))
                m2.metric("Status HTTP", response.status_code)
                st.dataframe(df, use_container_width=True, hide_index=True)

                csv = df.to_csv(index=False).encode("utf-8-sig")
                st.download_button(
                    "📥 Baixar dados em CSV",
                    data=csv,
                    file_name="dados_extraidos.csv",
                    mime="text/csv",
                )
            else:
                st.warning("A página foi acessada, mas nenhum link foi encontrado.")
        except ValueError as exc:
            st.error(str(exc))
        except requests.exceptions.HTTPError as exc:
            st.error(f"Erro HTTP: {exc}")
        except requests.exceptions.SSLError:
            st.error("Não foi possível validar a conexão segura (SSL) com esse site.")
        except requests.exceptions.Timeout:
            st.error("O site demorou demais para responder. Tente novamente.")
        except requests.exceptions.ConnectionError:
            st.error("Não foi possível conectar ao servidor.")
        except requests.exceptions.RequestException as exc:
            st.error(f"Erro ao consultar o site: {exc}")
        except Exception as exc:
            st.error(f"Ocorreu um erro inesperado: {exc}")

st.divider()
st.caption("Data Puller Panel • Python + Streamlit + BeautifulSoup")
