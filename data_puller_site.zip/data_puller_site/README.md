# Data Puller Panel

## Rodar no computador

1. Instale Python 3.10 ou mais recente.
2. Abra o terminal nesta pasta.
3. Instale as dependências:

   `pip install -r requirements.txt`

4. Inicie o site:

   `streamlit run app.py`

O Streamlit abrirá o painel no navegador. Para publicar online, envie estes arquivos para um serviço compatível com Streamlit, como o Streamlit Community Cloud.

Use apenas em páginas públicas e respeite os termos de uso e as permissões do site consultado.
